import re
import urllib.request
from bs4 import BeautifulSoup

url = "http://madam4060.com/"
soup = BeautifulSoup(urllib.request.urlopen("http://madam4060.com/shop/shopbrand.html?xcode=006&type=X"), "html.parser")

for link in soup.findAll('img', attrs={'class':'thumb_img'}):
    img_src = link.attrs['src']
    img_url = url + img_src
    img_name = img_src[19:31] # 이미지 src에서 / 없애기
    savename = "./test/" + img_name
    urllib.request.urlretrieve(img_url, savename + '.png')
